Author: Noah Swimmer
26 January 2022

A short description of the pipeline timescale testing files and output creation process. Please also read Pipeline_Output_Timescales.pdf for reference to what this test is doing and further discussison.

NOTE: All reduced data (h5s, fits files, etc.) and YAML files are on glados. All bin files are on dark in the standard /darkdata/ScienceData/Subaru/<date> directory. The output files are also stored in this zipped folder for reference.

To reproduce/rerun this dataset, you first need to make the h5s. These were created at 'out' directory /work/nswimmer/20211016/injectp/. Feel free to use this if that directory still exists, otherwise use /work/<username>/20211016/injectp/. For the rest of this README, I'll use the file structure with nswimmer as the username, but take note that if you are remaking those files you should replace that username with your own.

You can make the first set of useful outputs here by using the !MKIDOutput blocks below the commented line
'# --------------------------------- No injected planet ---------------------------------'. 
This requires 3 separate runs of the mkidpipe script. 1 with wcs_timestep:20 and timestep:1.0, 1 with wcs_timestep:1 and timestep:15.0, and 1 with wcs_timestep:1 and timestep:15.0 . To do this, simply comment out the 2 output classes you don't need, change the wcs_timestep in the pipe.yaml and run it, then repeat with the next outputs. NOTE: You do not NEED these fits outputs with no planet injected, but will allow you a reference to the same outputs you'll make with a planet injected, so you can look solely at the planet's behavior (which is what we're after).

Once these outputs have been made, it's time to inject a fake companion in. Because we are looking at 2 different t_psf timescales, you will need to inject a planet with 2 different rotation rates. This will be injected in h5 files contatined in /work/nswimmer/20211016/injectp/rrate0 and /work/nswimmer/20211016/injectp/rrate1. Once those two directories are made, copy as many of the h5s you would like to inject the planet into to each of those. Take note, trying to inject a companion into a wavecal file may cause issues (though that should have been fixed) and the data.yaml is currently set up to use the first 9 dither steps of the dither, and so I only copied those 9 h5s into the new directory.

Once the h5s are in the requisite folders, run the inject_planets.py code (contained here, but the important lines are 470-484, which should be able to imported into updated versions of the code). By uncommenting lines 470-484, you will inject 2 planets per directory. The point in this was for some redundancy, the planets are injected at the same separation and have the same count rate, but are 180 degrees separated from one another. If you'd like to change the separations or drop the count rates, that is allowed and will not break the code. However, it wil change t_psf, as that value was calculated specifically for separation=0.3", and so we do recommend leaving at least 1 planet at that separation.

Now, you'll make the outputs WITH the planet injected. This requires a few tweaks to the YAMLs that can be a bit tedious, but not hard.

First, in the pipe.yaml uncomment #  out: /work/nswimmer/20211016/injectp/rrate0/ and comment out: /work/nswimmer/20211016/injectp/. This is for the t_psf:8 test. Next, change wcs_timestep:20 in pipe.yaml, and uncomment the first two !MKIDOutput blocks in the out.yaml. Run mkidpipe.

After that runs, change wcs_timestep:1, comment out the two !MKIDOutput blocks that you just made, and uncomment the next two (if there is any confusion, they are named accordingly to the timescales, so you should see twcs1 in the filenames, which let you know you're making the right ones). Run mkidpipe

After that, uncomment #  out: /work/nswimmer/20211016/injectp/rrate1/ and comment out: /work/nswimmer/20211016/injectp/rrate0/ in pipe.yaml. Change wcs_timestep:50, and comment out the two !MKIDOutput blocks you just made in the data.yaml file, then uncomment the 2 following that (again, use the timescales in the output name to guide you). Run mkidpipe.

After that, change wcs_timestep:5 in the pipe.yaml and uncomment the final 2 !MKIDOutput blocks, comment out the two !MKIDOutput blocks you just made. Run mkidpipe.

You should now have all of the outputs to get you on your way to checking the potential problematic effects described in the 'pipeline_output_timescales.pdf' contained in this folder. 

If you so desire, you can manually subtract the 'no planet injected' outputs from the 'planet injected' outputs, so that you only have the planet to look at without getting swamped by other features in the observation. 